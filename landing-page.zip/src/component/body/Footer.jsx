import React from 'react'

const Footer = () => {
  return (
    <div style={{marginBottom:"10px",padding:'10px'}} >
      <div style={{float:"left"}}>
        Email: vishwanathpandey11@gmail.com
      </div>
      <div style={{float:'right'}}>
        Mobile: 8092815830
      </div>
    </div>
  )
}

export default Footer