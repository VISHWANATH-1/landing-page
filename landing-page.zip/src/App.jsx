import Navbar from './component/Navbar/Navbar';
import './App.css'
//import Footer from './component/Navbar/body/Footer';
function App() {
  return (
    <>
    <div className="App">
     <Navbar />
     {/* <Footer /> */}
    </div>
    
    </>
    
  );
}

export default App;
